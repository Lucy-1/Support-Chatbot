
from flask import Flask, render_template, request, jsonify
import json
import logging
from datetime import datetime

app = Flask(__name__)

logging.basicConfig(
    filename="media_chatbot.log",
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)

def load_content():
    with open("content.json") as f:
        return json.load(f)

def is_expired(content):
    today = datetime.now().date()
    end_date = datetime.strptime(content["end_date"], "%Y-%m-%d").date()
    return end_date < today

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    user_input = request.json.get("message")
    state = request.json.get("state", {})

    content = load_content()

    if not state:
        if is_expired(content):
            logging.warning("Expired content accessed")
            return jsonify({
                "reply": f"⛔ The content '{content['title']}' is expired. Chat ended.",
                "end": True
            })

        return jsonify({
            "reply": "What would you like to do?",
            "cards": ["Re-Transcode", "Re-Protect", "Re-Publish / Re-Ingest"],
            "state": {"step": "operation"}
        })

    if state["step"] == "operation":
        logging.info("Operation selected: %s", user_input)
        return jsonify({
            "reply": "Select platform:",
            "cards": ["SD", "HD", "NANO", "Explora"],
            "state": {"step": "platform", "operation": user_input}
        })

    if state["step"] == "platform":
        logging.info("Platform selected: %s", user_input)
        return jsonify({
            "reply": "Select region:",
            "cards": ["IS20", "E36B", "E36A"],
            "state": {
                "step": "region",
                "operation": state["operation"],
                "platform": user_input
            }
        })

    if state["step"] == "region":
        logging.info(
            "Job triggered | Operation=%s | Platform=%s | Region=%s",
            state["operation"], state["platform"], user_input
        )

        return jsonify({
            "reply": (
                f"✅ SUCCESS<br>"
                f"{state['operation']} completed on "
                f"{state['platform']} ({user_input}).<br>"
                f"Chat ended 👋"
            ),
            "end": True
        })

    return jsonify({"reply": "Unexpected error", "end": True})

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5050, debug=True)

