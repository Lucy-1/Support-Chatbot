
import json
import sys
import logging
from datetime import datetime

LOG_FILE = "media_chatbot.log"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger(__name__)

def load_content(json_file):
    with open(json_file, "r") as f:
        return json.load(f)

def is_content_expired(content):
    today = datetime.now().date()
    end_date = datetime.strptime(content["end_date"], "%Y-%m-%d").date()
    return end_date < today

def card_viewer(title, options):
    print(f"\n{title}")
    for i, opt in enumerate(options, 1):
        print(f"[{i}] {opt}")
    while True:
        try:
            choice = int(input("Select option: "))
            if 1 <= choice <= len(options):
                return options[choice - 1]
        except ValueError:
            pass
        print("Invalid choice")

def chatbot():
    logger.info("Chatbot started")
    content = load_content("content.json")

    if is_content_expired(content):
        logger.warning("Content expired")
        print("CONTENT EXPIRED. Chat ending.")
        return

    action = card_viewer("Select Operation", [
        "Re-Transcode",
        "Re-Protect",
        "Re-Publish / Re-Ingest"
    ])

    platform = card_viewer("Select Platform", ["SD", "HD", "NANO", "Explora"])
    region = card_viewer("Select Region", ["IS20", "E36B", "E36A"])

    logger.info(f"Operation={action}, Platform={platform}, Region={region}")
    print("SUCCESS. Operation completed. Chat ended.")

if __name__ == "__main__":
    chatbot()
