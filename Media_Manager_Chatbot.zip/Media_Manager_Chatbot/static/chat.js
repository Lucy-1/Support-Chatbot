let state = {};

function addMessage(text, sender) {
    const chat = document.getElementById("chat");
    const div = document.createElement("div");
    div.className = "message " + sender;
    div.innerHTML = text;
    chat.appendChild(div);
    chat.scrollTop = chat.scrollHeight;
}

function showCards(cards) {
    const container = document.getElementById("cards");
    container.innerHTML = "";

    cards.forEach(card => {
        const btn = document.createElement("button");
        btn.innerText = card;
        btn.onclick = () => sendMessage(card);
        container.appendChild(btn);
    });
}

function sendMessage(message) {
    if (message) {
        addMessage(message, "user");
    }

    document.getElementById("cards").innerHTML = "";

    fetch("/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message, state })
    })
    .then(res => res.json())
    .then(data => {
        // ALWAYS show bot reply
        addMessage(data.reply, "bot");

        if (data.cards) {
            showCards(data.cards);
            state = data.state;
        }

        if (data.end) {
            state = {};
        }
    });
}

// Start chat with backend greeting
sendMessage("start");
